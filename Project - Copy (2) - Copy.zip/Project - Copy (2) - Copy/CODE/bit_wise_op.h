#include "types.h"

#define SET_BIT(R, bit)  (R|=(1<<bit))    
#define clear_bit(R,bit) (R&=~(1<<bit)) 
#define TOGGLE (R,bit)   (R^=(1<<bit)) 
                          

