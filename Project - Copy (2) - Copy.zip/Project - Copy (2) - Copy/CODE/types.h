#ifndef TYPES_H_INCLUDED
#define TYPES_H_INCLUDED


#define int8  char
#define uint8 unsigned char
#define int32_ptr unsigned float
#define uint32_ptr unsigned int*
#define uint32   int

#endif // TYPES_H_INCLUDED
