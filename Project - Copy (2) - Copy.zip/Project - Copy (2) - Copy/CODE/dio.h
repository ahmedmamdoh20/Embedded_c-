#include "tm4c123gh6pm.h" 
#include "types.h"

void  Init(void);
void  portwrite (volatile unsigned long *R,uint8 value);
void  pinwrite  (volatile unsigned long *R,uint8 bit,uint8 value);

   
   
   