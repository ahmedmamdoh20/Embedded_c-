#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "tm4c123gh6pm.h" 
#include "dio.c"
#include "dio.h"
#include "bit_wise_op.h"
#include "types.h" 
void Timer0_Init(void);
void PORTFIntHandler();
//void Timer1_Init(void);
void Timer0A_delay (int time);
//void Timer1A_delay (int time);
int main()

{   InitPortF() ;
    InitPortE() ; 
    InitPortA() ;
    Timer0_Init();
    GPIO_PORTF_PUR_R=0x11;
    GPIOIntRegister(GPIO_PORTF_BASE, PORTFIntHandler);
    GPIOIntTypeSet(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_FALLING_EDGE);
    NVIC_EN0_R = 1<<30;
    __asm("CPSIE  I");
    __asm("   wfi");
    while(1)
    {
      GPIO_PORTF_DATA_R |= 0x02;
      GPIO_PORTE_DATA_R |= 0x02;
      GPIO_PORTA_DATA_R = 0x50;
      Timer0A_delay (5000);
      GPIO_PORTF_DATA_R &= ~(0x02);
      GPIO_PORTF_DATA_R |= 0x04;
      Timer0A_delay (2000);
      GPIO_PORTF_DATA_R &= ~ (0x04);
      GPIO_PORTF_DATA_R |= 0x08;
      GPIO_PORTA_DATA_R = 0xA0;
      Timer0A_delay (1000);
      GPIO_PORTE_DATA_R &= ~(0x02);
      GPIO_PORTE_DATA_R |= 0x10;
      Timer0A_delay (5000);
      GPIO_PORTE_DATA_R &= ~(0x10);
      GPIO_PORTE_DATA_R |= 0x20;
      Timer0A_delay (2000);
      GPIO_PORTE_DATA_R &= ~(0x20);
      GPIO_PORTE_DATA_R |= 0x02;
      Timer0A_delay (1000);
      GPIO_PORTE_DATA_R &= ~(0x02);
      GPIO_PORTF_DATA_R &= ~(0x08);
    }
    __asm("   wfi");
}
void Timer0_Init(void)
{ 
    SYSCTL_RCGCTIMER_R |= 0x1 ;   //clk enable
    TIMER0_CTL_R = 0x0;       //disable timer
    TIMER0_CFG_R = 0x04 ;     //16bit timer config.
    TIMER0_TAMR_R = 0x02;    //periodic mode and down-counter
}
void Timer0A_delay (int time)
{
  TIMER0_TAILR_R = ((16000) - 1);
  TIMER0_CTL_R |= 0x01;
  int i;
  for(i = 0; i < time; i++) 
  { 
         while (( TIMER0_RIS_R & 0x1) == 0) ;      /* wait for TimerA timeout flag */
         TIMER0_ICR_R = 0x1;                    /* clear the TimerA timeout flag */
         
  }
}
void PORTFIntHandler () 
{ 
        if(( GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_4)) == 0)
        {
            GPIO_PORTA_DATA_R |= 0x20;
            GPIO_PORTA_DATA_R &= ~(0x40);
            GPIO_PORTF_DATA_R = 0x08;
           while (( GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_4)) == 0 );
            Timer0A_delay (2000);
            GPIO_PORTA_DATA_R &= ~(0x20);
            GPIO_PORTA_DATA_R |= 0x40;
            GPIO_PORTF_DATA_R &= ~(0x08);
            GPIOIntClear(GPIO_PORTF_BASE, GPIO_INT_PIN_4 ) ; 
        }
        if(( GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_0)) == 0)
        {
            GPIO_PORTA_DATA_R |= 0x10;
            GPIO_PORTA_DATA_R &= ~(0x80);
            GPIO_PORTE_DATA_R = 0x02;
            while (( GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_0)) == 0 );
            Timer0A_delay (2000);
            GPIO_PORTA_DATA_R &= ~(0x10);
            GPIO_PORTA_DATA_R |= 0x80;
            GPIO_PORTE_DATA_R &= ~(0x02);
            GPIOIntClear(GPIO_PORTF_BASE, GPIO_INT_PIN_0 ) ; 
        }
        
}
/*void Timer1_Init(void)
{ 
    SYSCTL_RCGCTIMER_R |= 0x1 ;   //clk enable
    TIMER1_CTL_R = 0x0;       //disable timer
    TIMER1_CFG_R = 0x04 ;     //16bit timer config.
    TIMER1_TAMR_R = 0x02;    //periodic mode and down-counter
}
void Timer1A_delay (int time)
{
  TIMER1_TAILR_R = ((16000) - 1);
  TIMER1_CTL_R |= 0x01;
  int i;
  for(i = 0; i < time; i++) 
  { 
         while (( TIMER1_RIS_R & 0x1) == 0) ;      //wait for TimerA timeout flag 
         TIMER1_ICR_R = 0x1;                      //clear the TimerA timeout flag 
  }
}*/

