#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "tm4c123gh6pm.h" 
#include "dio.h"
#include "bit_wise_op.h"
#include "types.h" 

void InitPortF(void)
{
   SYSCTL_RCGCGPIO_R |= 0x00000020;
   while((SYSCTL_PRGPIO_R&0x00000020) == 0);
   GPIO_PORTF_LOCK_R = 0x4C4F434B;
   GPIO_PORTF_CR_R = 0x1F;
   GPIO_PORTF_DIR_R = 0x0E ; //pins 1,2,3 for 1st car traffic leds
   GPIO_PORTF_DEN_R = 0x0E;
   GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
   GPIO_PORTF_DATA_R ^= 0x00;
   GPIOIntEnable(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0);
 }
void InitPortE(void) 
{
   SYSCTL_RCGCGPIO_R |= 0x00000010;
   while((SYSCTL_PRGPIO_R&0x00000010) == 0);
  
   GPIO_PORTE_DIR_R = 0xF3; //pins 4,5,1 for 2nd car traffic leds
    GPIO_PORTE_DEN_R = 0xF3;
 }
void InitPortA(void) 
{
   SYSCTL_RCGCGPIO_R |= 0x00000001;
   while((SYSCTL_PRGPIO_R&0x00000001) == 0);
  
   GPIO_PORTA_DIR_R = 0xF0; //pins 4,5,6,7
    GPIO_PORTA_DEN_R = 0xF0;
 }

  